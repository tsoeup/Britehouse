﻿using System;
using System.Collections.Generic;

namespace Project3WebApp.Models.Orders
{
    public partial class Returns
    {
        public string Returned { get; set; }
        public string OrderId { get; set; }
        public string Region { get; set; }
    }
}
