﻿using System;
using System.Collections.Generic;

namespace Project3WebApp.Models.Orders
{
    public partial class People
    {
        public int ListId { get; set; }
        public string Column1 { get; set; }
        public string Column2 { get; set; }
    }
}
