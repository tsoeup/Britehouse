﻿namespace Project3WebApp
{
    internal class DataContext
    {
    }
}